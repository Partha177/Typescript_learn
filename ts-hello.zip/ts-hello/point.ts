export class Point{
    x:number;
    y:number;
    draw(){
        console.log("X : "+ this.x);
        console.log("X : "+ this.y);
    }
}