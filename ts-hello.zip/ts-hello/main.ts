// function log(message) {
//     console.log(message);
// }

// var message = "Hello World";

// log(message)

// function doSomething(){
//     for(let i = 0; i<5; i++){
//         console.log(i);
//     }
//     console.log("Finally : ", + i);
// }

// let a: number;
// let b: any;
// let c: boolean;
// let d: number[] = [1,2,3];
// let e: string;
// let f: any[] = [1, "PP", "%", 5];

// //OOP supports enum
// // enum Color{red, blue, purple}
// enum Color{red=2, blue=4, purple=0}
// let backgrounfColor = Color.red



// let message = "Bharat";
// let p =message.endsWith("t");
// console.log(p);


//type assertion
// let message;
// message = "abc"
// let ends = (message as string).endsWith("c");
// let swith = (<string>message).endsWith("c");

//arrow function
// let doLog = (message) => console.log(message);

//cohesion = things that are related should be part of one unit
//to implement this we use class of fields(variabbles) & methods

//interface
// interface Point{
//     x: number,
//     y:number,
//     // draw:() => void
// }

// let drawpoint = (point:Point)=>{
//     //algo
// }

// drawpoint({
//     x:1,
//     y:2,

// })


// OR
// class Point{
//     x:number;
//     y:number;
//     draw(){
//         console.log("X : "+ this.x);
//         console.log("X : "+ this.y);
//     }
//     getDistance(another: Point){

//     }

// }

// let point = new Point();
// point.x = 1;
// point.y = 2;
// point.draw();

//constructor
// class Point{
//     x:number;
//     y:number;

//     constructor(x:number, y: number) {
//         this.x = x;
//         this.y = y;
        
//     }

//     draw(){
//         console.log("X : "+ this.x);
//         console.log("Y : "+ this.y);
//     }
// }

// let point = new Point(1,2);
// point.draw();

//optional param
// class Point{
//     //fields--camelCase to define fields var
//     // private x:number;
//     // y:number;

//     // constructor(x?:number, y?: number) { //optional params
//     //     this.x = x;
//     //     this.y = y;
                
//     // }

//     constructor(private _x?: number, public y?: number){
//         //shortcut of above commented codes
//     }
//     //camel case
//     draw(){
//         console.log("X : "+ this._x);
//         console.log("Y : "+ this.y);
//     }

//     //methods
//     // getX(){
//     //     return this.x;
//     // }

//     // setX(value:number){
//     //     if(value<0)
//     //         throw new Error("Value cant be less than 0.");
//     //     this.x = value;
//     // }

//     //properties--Pascal case, to use camelCase add _ before variable
//     // get X(){
//     //     return this.x;
//     // }

//     // set X(value){
//     //     if(value<0)
//     //         throw new Error("Value can't be less than 0");
//     //     this.x = value;
//     // }
//     get x(){
//         return this._x;
//     }

//     set x(value){
//         if(value<0)
//             throw new Error("Value can't be less than 0");
//         this._x = value;
//     }

// }

// let point = new Point();
// //calling fields
// point.y = 5;
// //calling methods
// // let z = point.getX();
// // point.setX(10);

// //calling properties
// let z = point.x
// point.x = 10;

// //can't access to x like this
// point.draw();

// //Access Modifiers--public, private, protected

//TS supports modularity
import {Point} from './point';//importing types[classes, variable, objects, function]
let point = new Point();
point.draw();
//whenever there is an export and import on top of file, that file is a module in TS point of view

