// function log(message) {
//     console.log(message);
// }
// var message = "Hello World";
// log(message)
// function doSomething(){
//     for(let i = 0; i<5; i++){
//         console.log(i);
//     }
//     console.log("Finally : ", + i);
// }
// let a: number;
// let b: any;
// let c: boolean;
// let d: number[] = [1,2,3];
// let e: string;
// let f: any[] = [1, "PP", "%", 5];
// //OOP supports enum
// // enum Color{red, blue, purple}
// enum Color{red=2, blue=4, purple=0}
// let backgrounfColor = Color.red
// let message = "Bharat";
// let p =message.endsWith("t");
// console.log(p);
//type assertion
// let message;
// message = "abc"
// let ends = (message as string).endsWith("c");
// let swith = (<string>message).endsWith("c");
//arrow function
// let doLog = (message) => console.log(message);
//cohesion = things that are related should be part of one unit
//to implement this we use class of properties/fields(variabbles) & methods
//interface
// interface Point{
//     x: number,
//     y:number,
//     // draw:() => void
// }
// let drawpoint = (point:Point)=>{
//     //algo
// }
// drawpoint({
//     x:1,
//     y:2,
// })
// OR
// class Point{
//     x:number;
//     y:number;
//     draw(){
//         console.log("X : "+ this.x);
//         console.log("X : "+ this.y);
//     }
//     getDistance(another: Point){
//     }
// }
// let point = new Point();
// point.x = 1;
// point.y = 2;
// point.draw();
//constructor
var Point = /** @class */ (function () {
    function Point(x, y) {
        this.x = x;
        this.y = y;
    }
    Point.prototype.draw = function () {
        console.log("X : " + this.x);
        console.log("X : " + this.y);
    };
    return Point;
}());
var point = new Point(1, 2);
point.draw();
